LOCAL_PATH := $(call my-dir)
MAIN_LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := libcurl
LOCAL_SRC_FILES := libraries/curl/curl-android-$(TARGET_ARCH_ABI)/lib/libcurl.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libdobby
LOCAL_SRC_FILES := libraries/dobby/dobby-android-$(TARGET_ARCH_ABI)/lib/libdobby.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := MyLibName

# -std=c++17 is required to support AIDE app with NDK
LOCAL_CFLAGS := -w -s -Wno-error=format-security -fvisibility=hidden -fpermissive -fexceptions
LOCAL_CPPFLAGS := -w -s -Wno-error=format-security -fvisibility=hidden -Werror -std=c++17
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fpermissive -Wall -fexceptions
LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all,-llog
LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv2
LOCAL_ARM_MODE := arm

LOCAL_SRC_FILES := Main.cpp \
    LGL2Cpp/Il2Cpp.cpp \
    KittyMemory/KittyMemory.cpp \
    KittyMemory/MemoryPatch.cpp \
    KittyMemory/MemoryBackup.cpp \
    KittyMemory/KittyUtils.cpp \
    ImGui/imgui.cpp \
    ImGui/imgui_draw.cpp \
    ImGui/imgui_demo.cpp \
    ImGui/imgui_widgets.cpp \
    ImGui/imgui_tables.cpp \
    ImGui/backends/imgui_impl_opengl3.cpp \
    ImGui/backends/imgui_impl_android.cpp

LOCAL_C_INCLUDES += \
    $(LOCAL_PATH)/include \
    $(LOCAL_PATH)/ImGui \
    $(LOCAL_PATH)/ImGui/backends \
    $(LOCAL_PATH)/LGL2Cpp \
    $(LOCAL_PATH)/Includes \
    $(LOCAL_PATH)/Substrate \
    $(LOCAL_PATH)/KittyMemory \
    $(LOCAL_PATH)/Unity \
    $(LOCAL_PATH)/Stuffs \
    $(LOCAL_PATH)/Codes \
    $(NDK_ROOT)/sources/android/native_app_glue
    
    
LOCAL_C_INCLUDES += $(LOCAL_PATH)/libraries/dooby/dobby-android-$(TARGET_ARCH_ABI)/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/libraries/curl/curl-android-$(TARGET_ARCH_ABI)/include

LOCAL_LDLIBS := -lz -llog -landroid -lEGL -lGLESv1_CM -lGLESv2 -lGLESv3
LOCAL_STATIC_LIBRARIES := libcurl libdobby

include $(BUILD_SHARED_LIBRARY)
